
he = imread('a.bmp');
result = segmentImage(he)
imshow(result)
imshowpair(he,result,"blend")